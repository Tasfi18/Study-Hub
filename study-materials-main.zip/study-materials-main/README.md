# KU Study Materials - TypeScript Best Practices

A clean, TypeScript-based study materials management platform for Khulna University following modern best practices with minimal code complexity.

## 🚀 Features

- **Type-Safe Development**: Full TypeScript implementation 1
- **Clean Architecture**: Separation of concerns with minimal code duplication
- **Secure Authentication**: JWT with role-based access control
- **File Management**: Upload and organize study materials
- **Search & Filter**: Find materials by discipline, batch, and course
- **Q&A Community**: Ask questions and get answers from peers and teachers
- **Responsive Design**: Modern UI with Tailwind CSS

## 🛠 Tech Stack

**Backend**
- Node.js + TypeScript
- Express.js with proper middleware
- PostgreSQL with Supabase
- Zod for validation
- JWT authentication

**Frontend**  
- Next.js 14 with TypeScript
- Zustand for state management
- React Hook Form + Zod
- Tailwind CSS

## 📁 Project Structure

```
mern-study-materials/
├── backend/
│   ├── src/
│   │   ├── config/         # Database & app configuration
│   │   ├── controllers/    # Request handlers  
│   │   ├── middleware/     # Auth & validation
│   │   ├── routes/         # API endpoints
│   │   ├── services/       # Business logic
│   │   ├── types/          # TypeScript definitions
│   │   └── utils/          # Helper functions
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── app/           # Next.js pages
│   │   ├── components/    # React components
│   │   ├── lib/           # API client & utilities
│   │   ├── store/         # State management
│   │   └── types/         # TypeScript definitions
│   └── package.json
├── supabase/
│   └── schema.sql         # Database schema
├── package.json           # Root scripts for easy development
└── README.md
```

## 🚀 Quick Start

### 1. Clone & Install
```bash
# Clone and install everything
git clone <repository-url>
cd mern-study-materials
npm install
npm run install:all
```

### 2. Setup Environment Files
```bash
# Copy environment templates
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env.local

# Edit the files with your Supabase credentials
```

### 3. Database Setup
1. Create a Supabase project
2. Copy the SQL from `supabase/schema.sql` and run it in Supabase SQL editor
3. Update your `.env` files with Supabase credentials

### 4. Start Development

**Simple command (recommended):**
```bash
npm run dev
```

**Manual start (alternative):**
```bash
# Terminal 1 - Backend
cd backend && npm run dev

# Terminal 2 - Frontend  
cd frontend && npm run dev
```

### 5. Access Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- Health check: http://localhost:5000/health

## 🔧 Development Commands

**Backend**
```bash
npm run dev          # Development server
npm run build        # Build TypeScript
npm start            # Production server
npm test             # Run tests
npm run lint         # Check code quality
```

**Frontend**
```bash
npm run dev          # Development server
npm run build        # Build for production
npm start            # Production server
npm run lint         # Check code quality
```

## 🏗 TypeScript Best Practices Implemented

### 1. **Type Safety**
- Strict TypeScript configuration
- Shared type definitions between frontend/backend
- Zod schemas for runtime validation
- No `any` types in production code

### 2. **Clean Architecture**
- Separation of concerns (controllers, services, utils)
- Single responsibility principle
- Dependency injection where appropriate
- Consistent error handling

### 3. **Code Quality**
- ESLint + TypeScript rules
- Consistent naming conventions
- Modular, reusable components
- Comprehensive error handling

### 4. **Security**
- JWT authentication
- Input validation with Zod
- SQL injection prevention
- File type validation
- Rate limiting

### 5. **Performance**
- Efficient database queries
- Proper indexing
- Image optimization
- Code splitting

## 🚀 Production Deployment

### Build for Production
```bash
# Build backend
cd backend
npm run build

# Build frontend
cd ../frontend  
npm run build
```

### Start Production Servers
```bash
# Start backend
cd backend
npm start

# Start frontend (in another terminal)
cd frontend
npm start
```

### Cloud Deployment (Recommended)
- **Frontend**: Deploy to [Vercel](https://vercel.com) (automatic with Git)
- **Backend**: Deploy to [Railway](https://railway.app) or [Render](https://render.com)
- **Database**: Use [Supabase](https://supabase.com) (already configured)

## 🧪 Testing

```bash
cd backend
npm test              # Run unit tests
npm run test:watch    # Watch mode
```

## 🤝 Contributing

1. Follow TypeScript best practices
2. Use existing code patterns
3. Add tests for new features
4. Keep components under 200 lines
5. Use meaningful commit messages

## 📝 API Endpoints

```
POST /api/auth/login        # User login
POST /api/auth/register     # User registration
GET  /api/materials         # List materials
POST /api/materials         # Upload material
GET  /api/materials/:id     # Get material
GET  /api/materials/:id/download # Download material
GET  /api/questions         # List questions
POST /api/questions         # Create question
GET  /api/questions/:id     # Get question with answers
POST /api/questions/:id/answers # Add answer to question
PUT  /api/questions/:questionId/answers/:answerId/accept # Accept answer
```

## 🔍 Key Files

- `backend/src/server.ts` - Main server file
- `backend/src/types/index.ts` - Type definitions
- `frontend/src/app/page.tsx` - Home page
- `frontend/src/lib/api.ts` - API client
- `supabase/schema.sql` - Database schema

---

Built with ❤️ following TypeScript best practices and minimal complexity.